function mostrarPopup() {
    document.getElementById("miPopup").style.display = "block";
}

function cerrarPopup() {
    document.getElementById("miPopup").style.display = "none";
}